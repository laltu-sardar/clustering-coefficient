Important : Please read till end at least once before running codes.

Libraries Required to be installed
-----------------------------------
1. Make sure "g++" compiler (latest version) is installed on system.
 
2. Crypto++ (version 8.2 or later). Installation should be done on Linux OS.
            Download Link: https://www.cryptopp.com/cryptopp820.zip
            Installation Instructions: https://www.cryptopp.com/wiki/Linux

Make sure library is installed correctly as per instructions given on link.
************************************* END *********************************************


Command line instructions to run codes
---------------------------------------
Example Code - "abc.cpp"
1. Compile :- g++ -I/usr/local/include/cryptopp abc.cpp -o abc.exe -lcryptopp -lpthread 
2. Run :- ./abc.exe

Codes :- a)encrypt.cpp   b)edge.cpp   c)neighbour.cpp   d)cc.cpp   e)addvertex.cpp  f)addedge.cpp
***************************************** END *****************************************************


Before Running Codes - Important
---------------------------------
Example Graph file - "abc.txt" where "abc" is graph name.

1. Dataset :- User has to create a directory named "Dataset". All the graph files which has to be encrypted have to be stored in this directory.

2. Testcase files :- a) Edge Query: Testcase file should be named like "abced.txt" (for "abc.txt" graph file). File should contain 2 space separated integers per line.   
                     b) Neighbour and CC Query : Testcase file should be named like "abcncc.txt" (for "abc.txt" graph file). File should contain 1 integer per line.
   No extra directory is needed to store Testcase files.
   Note:- Each testcase file is assumed to have 1000 lines.

3. Input Format :- While running code, if user is prompted to enter "graph datafile" then user has to enter, say "abc.txt" (by the name it has been stored in Dataset directory).

4. Edge, Neighbour and CC Codes :- To run test for "abc.txt", user has to add "abc" in "data" array in main function and adjust the value of "for loop counter" before running.
************************************************************************************** END *********************************************************************************************


Codes Output 
-------------
Example Graph file - "abc.txt" where "abc" is graph name.

1. encrypt.cpp :- a) "Encryption Results" directory will be created having three directories , say "abc_TV", "abc_TE", "abc_SV".
                  b) "Keyset" Directory will be created having file named ,say "abc_key_iv.txt" containing keys and ivs used for encryption.

2. edge.cpp :- "Edge Results" directory will be created having two files, say "abc Edge.txt" and "abc Edge Query Time.txt".

3. neighbour.cpp :-  "Neighbour Results" directory will be created having two files, say "abc Neighbour.txt" and "abc Neighbour Query Time.txt".

4. cc.cpp :-  "CC Results" directory will be created having two files, say "abc CC.txt" and "abc CC Query Time.txt".

5. addvertex.cpp :- Output is on console window.

6. addedge.cpp :- Output is on console window.
                  Important Note : Make sure that the edge you want to add must not exist before in graph. Failing to do so will produce wrong results.
************************************************************************* END ********************************************************************************** 


Outputs: ABC = datafilename
res_ABC_CC.txt 			: Vertex,	Result,	Time(microseconds),	Neighbor,	Neighbor of Neighbors
res_ABC_Enc.txt			: Time (milisecond)
res_ABC_Edge.txt		: u,	v,	ResultBit,	Time(microseconds)
res_ABC_Neighbor.txt	: Vertex,	Neighbors,	Time(microseconds)
res_ABC_AddEdge.txt		: u , v, Token gen Time(microseconds)
res_ABC_AddVertex.txt	: VertexID,		Time(microseconds)

//g++ -I/usr/local/include/cryptopp final_code_v2.cpp -o final_code_v2 -l:libcryptopp.a --Compiling
//./final_code_v2  --For running

//General CPP
#include <bits/stdc++.h>
//General Cryptopp
#include "cryptlib.h"
#include "osrng.h"
#include "hex.h"
#include "filters.h"
#include "secblock.h"
//AES
#include "aes.h"
#include "modes.h" //CFB Mode
//HMAC
#include "hmac.h"
#include "sha.h"
//Salsa20
#include "salsa.h"

using namespace std;
using namespace CryptoPP;
using namespace std::chrono;

typedef CryptoPP::byte Byte;      //Cryptopp Byte
typedef pair<pair<string,pair<string,string>>,pair<string,pair<string,string>>> vertex;  //for add vertex
typedef pair<string,pair<string,string>> key_val;  //for add edge

string encoded;
string kn,ka,kr,kl,kr0,kl0,iv_aes,iv_salsa;  //keys
unordered_map <string, pair<string,string> > tv,te;
unordered_map <string, string> sv;
int ngh,nngh;  //for cc query: no. of neighbors, no. of neighbors of neighbors

/********** cipher_hex ***********/
string cipher_hex(string cipher)
{
	encoded.clear();
	StringSource(cipher, true,
		new HexEncoder(
			new StringSink(encoded)
		) // HexEncoder
	); // StringSource

    return encoded;
}
//*********************************

/******** Bit_Extend funcion********/
void bit_extend(string &val)
{
    int pad = 32 - val.size();
    if(pad < 0){
        cout << "Node value is greater than 256 bit" << endl;
        exit(-1);
    }
    for(int i=0; i < pad; i++)
        val.push_back('.');
}
//*********************************

/********* XOR of encrypted strings *********/
string xor_enc(string c1, string c2)
{
    Byte* val1 = (Byte *)c1.data();
    Byte* val2 = (Byte *)c2.data();
    Byte res[32];   //assuming 256 bit

    for(int i=0; i < 32; i++)
       res[i]=val1[i] ^ val2[i];

    string result( reinterpret_cast<char const*>(res), 32);

    return result;
}
//*********************************

/********* P_Enc (AES Encryption,CFB Mode) ************/
string P_Enc(string ky, string plain)
{
    string cipher;
    Byte* key = (Byte *)ky.data();
    Byte* iv = (Byte *)iv_aes.data();
	try
	{
		CFB_Mode< AES >::Encryption e;
		e.SetKeyWithIV(key, 32, iv);   //using 256 bit key length, iv = ivaes

		// CFB mode must not use padding. Specifying a scheme will result in an exception
		StringSource(plain, true,
			new StreamTransformationFilter(e,
				new StringSink(cipher)
			) // StreamTransformationFilter
		); // StringSource
	}
	catch(const CryptoPP::Exception& e)
	{
		cerr << e.what() << endl;
		exit(1);
	}

    return cipher;
}
//************************************

/************* HMAC_256: H fun *************/
string H (string ky, string message)
{
    string mac;
    Byte* key = (Byte *)ky.data();

	try
	{
		HMAC< SHA256 > hmac(key, 32);  //default key length 256 bits

		StringSource(message, true,
			new HashFilter(hmac,
				new StringSink(mac)
			) // HashFilter
		); // StringSource
	}
	catch(const CryptoPP::Exception& e)
	{
		cerr << e.what() << endl;
		exit(1);
	}

    return mac;
}
//*************************************

/********* F_Enc (Salsa20 Encryption) ************/
string F_Enc(string ky, string plain)
{
    string cipher;
    Byte* key = (Byte *)ky.data();
    Byte* iv = (Byte *)iv_salsa.data();

    Salsa20::Encryption enc;
    enc.SetKeyWithIV(key, 32, iv, 8);   //default key length 256 bits,iv = 64 bits

    cipher.resize(plain.size());
    enc.ProcessData((Byte*)&cipher[0], (const Byte*)plain.data(), plain.size());

    return cipher;
}
//************************************

/********* F_Dec (Salsa20 Decryption) ************/
string F_Dec(string ky, string cipher)
{
    string plain;
    Byte* key = (Byte *)ky.data();
    Byte* iv = (Byte *)iv_salsa.data();

    Salsa20::Decryption dec;
    dec.SetKeyWithIV(key, 32, iv, 8);

    plain.resize(cipher.size());
    dec.ProcessData((Byte*)&plain[0], (const Byte*)cipher.data(), cipher.size());

    return plain;
}
//***********************************

/*********** set_intersection ***********/
int set_intersection_size(set<string> s1, set<string> s2)
{
    if(s1.size()==0 || s2.size()==0)  //empty set case
        return 0;
    set <string> :: iterator itr;
    int sint=0;
    for(itr = s1.begin(); itr != s1.end(); itr++)
    {
        if(s2.count(*itr))
            sint++;
    }
    return sint;
}
//*************************************

/*********** Key Generation ************/
vector<string> key_gen()
{
    vector<string> keys(8);
    SecByteBlock k(32),iv(8);
	AutoSeededRandomPool prng;         //seeding

    for(int i = 0; i < 7; i++)
    {
       prng.GenerateBlock(k, 32);
       StringSource(k, 32,true,new StringSink(keys[i]));  //generating kn,ka,kr,kl,kr0,kl0,ivaes in order
    }

    prng.GenerateBlock(iv, 8);     //generating ivsalsa
    StringSource(iv, 32,true,new StringSink(keys[7]));

    return keys;
}
//***************************************

/*********** Encrypt Function *************/
void encrypt(string graph, vector<string> keys)
{
    string prev="",line,v,nv,av,rv,lv,rv0,lv0,key,key0,nvi1,nvi,rvi,tp;
    Byte temp[32];
    pair<string,string> val,val0;
    int flag = 0;

    kn = keys[0];
    ka = keys[1];
    kr = keys[2];
    kl = keys[3];
    kr0 = keys[4];
    kl0 = keys[5];
    iv_aes = keys[6];
    iv_salsa = keys[7];

    ifstream infile(graph);   //opening datafile
    if(!infile)
    {
        cerr << "Graph Datafile does not exist !!" << endl;
        exit(-1);
    }

    //Encrypting graph file
    while(getline(infile,line))   //loop begins
    {
        stringstream str(line);
        str >> v;   //node value -> v

        if(prev != v)  //if new node comes
        {
            //adding last neighbour of previous node
            if(flag == 1)
            {
                nvi = "00000000000000000000000000000000";   //nvi = null
                rvi = "00000000000000000000000000000000";   //rvi = null

                key0 = H(av,nvi1);  //H(av,nv(i-1));
                tp = H(rv0,nvi1);
                val0.first = xor_enc(nvi,tp); //(nvi xor H(rv0,nvi-1))
                tp = H(lv0,nvi1);
                val0.second = xor_enc(rvi,tp); //(rvi xor H(lv0,nvi-1))
                te[key0] = val0;  //adding in Te
                sv[prev] = nvi1; //adding in Sv
            }
            //changing prev node value
            prev = v;
            bit_extend(v);       //making v of 256 bit length
            //making entry of new node in tv
            nv = P_Enc(kn,v);   //SE.Enc(kn,v)
            av = H(ka,v);  //P(ka,v)
	        AutoSeededRandomPool prng;
            prng.GenerateBlock(temp, 32);
            string nv0(reinterpret_cast<char const*>(temp), 32); //nv0
            rv = H(kr,v);  //P(kr,v)
            lv = H(kl,v); //P(kl,v)
            rv0 = H(kr0,v); //P(kr0,v)
            lv0 = H(kl0,v); //P(kl0,v)
            key = nv;
            tp = av+rv0+nv0;
            val.first = F_Enc(rv,tp);
            val.second = xor_enc(lv0,lv);
            tv[key] = val;   //adding in Tv
            nvi1 = nv0;  //initializing nv(i-1)
            flag = 1;
        }

        str >> v;  //for edges-> creating Te
        bit_extend(v);
        nvi = P_Enc(kn,v);   //SE.Enc(kn,vi)
        rvi = H(kr,v);  //P(kr,vi)
        key0 = H(av,nvi1);  //H(av,nv(i-1));
        tp = H(rv0,nvi1);
        val0.first = xor_enc(nvi,tp); //(nvi xor H(rv0,nvi-1))
        tp = H(lv0,nvi1);
        val0.second = xor_enc(rvi,tp); //(rvi xor H(lv0,nvi-1))
        te[key0] = val0;  //adding in Te
        nvi1 = nvi;  //nvi-1 = nvi;

    }
    //adding last entry in graph
    nvi = "00000000000000000000000000000000";   //nvi = null
    rvi = "00000000000000000000000000000000";   //rvi = null
    key0 = H(av,nvi1);  //H(av,nv(i-1));
    tp = H(rv0,nvi1);
    val0.first = xor_enc(nvi,tp); //(nvi xor H(rv0,nvi-1))
    tp = H(lv0,nvi1);
    val0.second = xor_enc(rvi,tp); //(rvi xor H(lv0,nvi-1))
    te[key0] = val0;  //adding in Te
    sv[prev] = nvi1; //adding in Sv

    infile.close();
}
//*************************************************************
/************* Main Encrypt Function **************/
void encrypt_graph(string graph, vector<string> key_iv){
    string enc_out_file =  "results/res_"+ graph + "_Enc.txt";
	graph = "datasets/"+ graph + "_src.txt";  //graph file
    ofstream out(enc_out_file,ios_base::app);  //opening encryption time result file in append mode
    if(!out){
        cout << "Encryption Time Result file cannot be created !!";
        exit(-1);
    }
    auto start = high_resolution_clock::now();
    encrypt(graph,key_iv);  //encryption starts here
    auto stop = high_resolution_clock::now();
    duration<double,milli> duration = stop - start;
    out<<  duration.count() << endl;
    cout << "Encryption Time = " << duration.count() << " milliseconds." << endl;
    out.close();
}
//******************************************

/************* Edge Query Token **************/
string edge_query_token(string u, string v)
{
    bit_extend(u);   //making u 256 bit
    bit_extend(v);  //making v 256 bit
    string au,nv,token;
    au = H(ka,u);
    nv = P_Enc(kn,v);
    token = H(au,nv);
    return token;
}
/************* Edge Query Function ***************/
bool edge_query(string token){
    //finding edge
    if(te.find(token) == te.end())
        return false;
    else
        return true;
}
//***************************************

/************* Neighbour Query Token **************/
pair<string,string> neighbour_query_token(string v)
{
    bit_extend(v);
    pair<string,string> token;
    token.first = P_Enc(kn,v);
    token.second = H(kr,v);
    return token;
}
/************* Neighbour Query **************/
set<string> neighbour_query(pair<string,string> token){
    //retrieving token
    string nv,rv;
    nv = token.first;
    rv = token.second;
    //performing query
    string av,rv0,nv0,temp,nvi1,key0,nvi;
    set<string> neighbors;
    pair<string,string> val,val0;
    if(tv.find(nv) == tv.end())
        return neighbors;       //if vertex not present
    else
        val = tv[nv];
    temp = val.first;
    temp = F_Dec(rv,temp);
    av = temp.substr(0,32);
    rv0 = temp.substr(32,64);
    nv0 = temp.substr(64,96);
    nvi1 = nv0;
    while(1)
    {
        key0 = H(av,nvi1);
        val0 = te[key0];
        nvi = xor_enc(val0.first, H(rv0,nvi1));
        if(nvi == "00000000000000000000000000000000")
            break;
        nvi1 = nvi;
        neighbors.insert(nvi);
    }

    return neighbors;
}
//***************************************

/************* CC Query Token ***************/
tuple<string,string,string> cc_query_token(string v)
{
    string nv,rv,lv;
    tuple<string,string,string> token;
    bit_extend(v);
    rv = H(kr,v);
    lv = H(kl,v);
    nv = P_Enc(kn,v);
    token = make_tuple(nv,rv,lv);
    return token;
}
/************* CC Query *************/
double cc_query(tuple<string,string,string> token)
{
    string nv,rv,lv,av,rv0,lv0,nv0,temp,nvi1,key0,nvi,rvi;
    set<string> R0;
    vector<set<string>> Ri;
    pair<string,string> val,val0,ntoken;
    double cc = -1;
    ngh=0; nngh=0;
    //retrieving token
    tie(nv,rv,lv) = token;
    if(tv.find(nv) == tv.end())
        return cc;       //if vertex not present
    else
        val = tv[nv];
    //performing query
    temp = val.first;
    temp = F_Dec(rv,temp);
    av = temp.substr(0,32);
    rv0 = temp.substr(32,64);
    nv0 = temp.substr(64,96);
    lv0 = xor_enc(val.second,lv);
    nvi1 = nv0;
    while(1)
    {
        key0 = H(av,nvi1);
        val0 = te[key0];
        nvi = xor_enc(val0.first, H(rv0,nvi1));
        rvi = xor_enc(val0.second, H(lv0,nvi1));
        if((nvi == "00000000000000000000000000000000") && (rvi == "00000000000000000000000000000000"))
            break;
        nvi1 = nvi;
        ntoken = make_pair(nvi,rvi);
        R0.insert(nvi);
        Ri.push_back(neighbour_query(ntoken));
    }
    //calculating clustering coefficient
    int d=0,s=0;
    d = R0.size();   //no. of neighbors of queried edge
    ngh = d;
    for(int i = 0; i < d; i++){
        nngh += Ri[i].size();
        s += set_intersection_size(R0,Ri[i]);
    }
    if((d == 0) || (d == 1))
        cc = 0;
    else
        cc = (double)s/(d*(d-1));
    return cc;
}
//************************************

/************* Add Vertex Token ***************/
vertex add_vertex_token(string v)
{
    string vr = v;
    string nv,av,rv,lv,rv0,lv0,key,key0,tp;
    Byte temp[32];
    pair<string,string> val,val0;
    key_val tk1,tk2;
    vertex token;
    string nvi = "00000000000000000000000000000000";   //nvi = null;
    if(sv.find(vr) != sv.end())  //if node already present
        return token;
    bit_extend(v);       //making v of 256 bit length
    //making entry of new node in tv
    nv = P_Enc(kn,v);   //SE.Enc(kn,v)
    av = H(ka,v);  //P(ka,v)
	AutoSeededRandomPool prng;
    prng.GenerateBlock(temp, 32);
    string nv0(reinterpret_cast<char const*>(temp), 32); //nv0
    rv = H(kr,v);  //P(kr,v)
    lv = H(kl,v); //P(kl,v)
    rv0 = H(kr0,v); //P(kr0,v)
    lv0 = H(kl0,v); //P(kl0,v)
    sv[vr] = nv0; //adding in sv
    key = nv;
    tp = av+rv0+nv0;
    val.first = F_Enc(rv,tp);
    val.second = xor_enc(lv0,lv);
    key0 = H(av,nv0);
    tp = H(rv0,nv0);
    val0.first = xor_enc(nvi,tp); //(null xor H(rv0,nv0))
    tp = H(lv0,nv0);
    val0.second = xor_enc(nvi,tp); //(null xor H(lv0,nv0))
    tk1 = {key,val};
    tk2 = {key0,val0};
    token = {tk1,tk2};
    return token;
}
/************* Add Vertex *************/
void add_vertex(vertex token)
{
    if(token.first.first == "") //if vertex already present
        return;
    string key,key0;
    pair<string,string> val,val0;
    key = token.first.first;
    key0 = token.second.first;
    val = token.first.second;
    val0 = token.second.second;
    //adding in tv and te
    tv[key] = val;
    te[key0] = val0;
}
//*******************************

/************* Add Edge Token ************/
vector<key_val> add_edge_token(string u, string v)
{
    string nv,nu,ru,rv,nvi1,nui1,av,rv0,lv0,au,ru0,lu0,key_u,key_v,key_u0,key_v0,tp;
    string nvi = "00000000000000000000000000000000";   //nvi = null;
    pair<string,string> val_v,val_v0,val_u0,val_u;
    vector<key_val> token;
    string vr=v, ur=u;
    //check vertices present or not
    if(sv.find(ur)==sv.end()){
        cout << "Vertex " << ur << " doesn't exist !!" << endl;
        return token;
    }
    if(sv.find(vr)==sv.end()){
        cout << "Vertex " << vr << " doesn't exist !!" << endl;
        return token;
    }
    if(edge_query(edge_query_token(ur,vr)))   //if edge already present
        return token;

    bit_extend(v);
    bit_extend(u);
    nv = P_Enc(kn,v);  //SE.Enc(kn,v)
    nu = P_Enc(kn,u);  //SE.Enc(kn,u)
    rv = H(kr,v);  //P(kr,v)
    ru = H(kr,u);  //P(kr,u)
    av = H(ka,v);  //P(ka,v)
    au = H(ka,u);  //P(ka,u)
    rv0 = H(kr0,v); //P(kr0,v)
    ru0 = H(kr0,u); //P(kr0,u)
    lv0 = H(kl0,v); //P(kl0,v)
    lu0 = H(kl0,u); //P(kl0,u)
    //finding last neighbour of v and u and replacing it
    nvi1 = sv[vr];
    nui1 = sv[ur];
    sv[vr] = nu;
    sv[ur] = nv;
    //new key value pairs to be added in u
    key_u = H(au,nv);
    val_u.first = xor_enc(nvi,H(ru0,nv));  //null xor H
    val_u.second = xor_enc(nvi,H(lu0,nv));
    //new key value pairs to be added in v
    key_v = H(av,nu);
    val_v.first = xor_enc(nvi,H(rv0,nu));
    val_v.second = xor_enc(nvi,H(lv0,nu));
    //old key value pair to be replaced in u
    key_u0 = H(au,nui1);
    val_u0.first = xor_enc(nv,H(ru0,nui1));
    val_u0.second = xor_enc(rv,H(lu0,nui1));
    //old key value pair to be replaced in v
    key_v0 = H(av,nvi1);
    val_v0.first = xor_enc(nu,H(rv0,nvi1));
    val_v0.second = xor_enc(ru,H(lv0,nvi1));

    token.push_back({key_u0,val_u0});
    token.push_back({key_v0,val_v0});
    token.push_back({key_u,val_u});
    token.push_back({key_v,val_v});

    return token;
}
/************* Add Edge *************/
void add_edge(vector<key_val> token)
{
    if(token.size()==0)
        return;
    //replacing old values
    te[token[0].first] = token[0].second;  //in u
    te[token[1].first] = token[1].second;  //in v
    //adding new values
    te[token[2].first] = token[2].second;  //in u
    te[token[3].first] = token[3].second;  //in v
}
//*******************************

/************* Edge Query Test ************/
void edge_query_test(string graph, string testfile)
{
	string edge_out_file =  "results/res_"+ graph + "_Edge.txt";
    ifstream test(testfile);
    if(!test){
        cout << "Edge Query Test File not present !!" << endl;
        return;
    }
	ofstream out(edge_out_file);
    if(!out){
        cout << "Edge Query Result File creation failed !!" << endl;
        return;
    }
    //out << "\t\t\tEdge Query Result file for " << graph << "\n\n";
    //out << "u\tv\tResult\tTime(microseconds)" << endl;
    int queries = 0;
    double time;
    string u,v,line;
    bool result;
    while(getline(test,line)){
        stringstream str(line);
        str >> u >> v;
        queries++;
        auto start = high_resolution_clock::now();  //time starts
        result = edge_query(edge_query_token(u,v));  //edge query
        auto stop = high_resolution_clock::now();
        duration<double,micro> duration = stop - start;
        time += duration.count();
        out << u << "\t" << v << "\t" << result << "\t\t" << duration.count() << endl;
    }
    out << endl;
    //out << "Time taken for " << queries <<  " edge queries = " << time << " microseconds" << endl;
    //out << "Average Time taken for edge query = " << time/queries << " microseconds";
    cout << "Average Time taken for edge query = " << time/queries << " microseconds" << endl;
}
/************* Neighbour Query Test *************/
void neighbour_query_test(string graph, string testfile)
{
	string neighbor_out_file =  "results/res_"+ graph + "_Neighbor.txt";
    ifstream test(testfile);
    if(!test){
        cout << "Neighbour Query Test File not present !!" << endl;
        return;
    }
	ofstream out(neighbor_out_file);
    if(!out){
        cout << "Neighbour Query Result File creation failed !!" << endl;
        return;
    }
    //out << "\t\t\tNeighbour Query Result file for " << graph << "\n\n";
    //out << "Vertex\tNeighbors\tTime(microseconds)" << endl;
    int queries = 0;
    double time;
    string v,line;
    set<string> result;
    while(getline(test,line)){
        stringstream str(line);
        str >> v;
        queries++;
        auto start = high_resolution_clock::now();  //time starts
        result = neighbour_query(neighbour_query_token(v));  //neighbour query
        auto stop = high_resolution_clock::now();
        duration<double,micro> duration = stop - start;
        time += duration.count();
        out <<  v << "\t\t" << result.size() << "\t\t\t" << duration.count() << endl;
    }
    out << endl;
    //out << "Time taken for " << queries <<  " neighbour queries = " << time << " microseconds" << endl;
    //out << "Average Time taken for neighbour query = " << time/queries << " microseconds";
    cout << "Average Time taken for neighbour query = " << time/queries << " microseconds" << endl;
}
/************* CC Query Test ***************/
void cc_query_test(string graph, string testfile)
{
	string cc_out_file =  "results/res_"+ graph + "_CC.txt";
    ifstream test(testfile);
    if(!test){
        cout << "CC Query Test File not present !!" << endl;
        return;
    }
	ofstream out(cc_out_file);
    if(!out){
        cout << "CC Query Result File creation failed !!" << endl;
        return;
    }
    //out << "\t\t\tCC Query Result file for " << graph << "\n\n";
    //out << "Vertex\tResult\tTime\tNeighbor\tNeighbor of Neighbors" << endl;
    int queries = 0;
    double time;
    string v,line;
    double result;
    while(getline(test,line)){
        stringstream str(line);
        str >> v;
        queries++;
        auto start = high_resolution_clock::now();  //time starts
        result = cc_query(cc_query_token(v));  //cc query
        auto stop = high_resolution_clock::now();
        duration<double,micro> duration = stop - start;
        time += duration.count();
        out <<  v << "\t\t" << result << "\t\t\t" << duration.count() << "\t\t" << ngh<< "\t\t" << nngh << endl;
    }
    out << endl;
    //out << "Time taken for " << queries <<  " cc queries = " << time << " microseconds" << endl;
    //out << "Average Time taken for cc query = " << time/queries << " microseconds";
    cout << "Average Time taken for cc query = " << time/queries << " microseconds" << endl;
}
/************* Add vertex Query Test ***************/
void add_vertex_query_test(string graph, string testfile)
{
	string addVertex_out_file =  "results/res_"+ graph + "_AddVertex.txt";
    ifstream test(testfile);
    if(!test){
        cout << "Add vertex Query Test File not present !!" << endl;
        return;
    }
    ofstream out(addVertex_out_file);
    if(!out){
        cout << "Add Vertex Query Result File creation failed !!" << endl;
        return;
    }
    //out << "\t\t\tAdd vertex Query Result file for " << graph << "\n\n";
    //out << "Vertex\t\tTime(microseconds)" << endl;
    int queries = 0;
    double time;
    string v,line;
    while(getline(test,line)){
        stringstream str(line);
        str >> v;
        queries++;
        auto start = high_resolution_clock::now();  //time starts
        add_vertex(add_vertex_token(v));  //cc query
        auto stop = high_resolution_clock::now();
        duration<double,micro> duration = stop - start;
        time += duration.count();
        out <<  v << "\t\t" << duration.count() << endl;
    }
    out << endl;
    //out << "Time taken for " << queries <<  " add vertex queries = " << time << " microseconds" << endl;
    //out << "Average Time taken for add vertex query = " << time/queries << " microseconds";
    cout << "Average Time taken for add vertex query = " << time/queries << " microseconds" << endl;
}
/************* Add Edge Query Test ***************/
void add_edge_query_test(string graph, string testfile)
{
	string addEdge_out_file =  "results/res_"+ graph + "_AddEdge.txt";
    ifstream test(testfile);
    if(!test){
        cout << "Add edge Query Test File not present !!" << endl;
        return;
    }
	ofstream out(addEdge_out_file);
    if(!out){
        cout << "Add Edge Query Result File creation failed !!" << endl;
        return;
    }
    //out << "\t\t\tAdd Edge Query Result file for " << graph << "\n\n";
    //out << "u\tv\t\tToken gen Time(microseconds)" << endl;
    int queries = 0;
    double time;
    string u,v,line;
    while(getline(test,line)){
        stringstream str(line);
        str >> u;
        str >> v;
        queries++;
        auto start = high_resolution_clock::now();  //time starts
		vector<key_val> token =  add_edge_token(u,v);
        auto stop = high_resolution_clock::now();
		add_edge(token);  //add edge query
        duration<double,micro> duration = stop - start;
        time += duration.count();
        out <<  u << "\t" << v << "\t\t\t" << duration.count() << endl;
    }
    out << endl;
    //out << "Time taken for " << queries <<  "add edge queries = " << time << " microseconds" << endl;
    //out << "Average Time taken for add edge query = " << time/queries << " microseconds";
    cout << "Average Time taken for add edge query = " << time/queries << " microseconds" << endl;
}
//********************************

int main()
{
    string graph,edge_test,neighbour_test,cc_test,adv_test,ade_test, dataDir;
    vector<string> key_iv;

	//graph = "sample";// only change here before running the code
	//graph = "cahepph";// only change here before running the code
	//graph = "gowalla";// only change here before running the code
	graph = "enron";// only change here before running the code
	//graph = "roadnet";// only change here before running the code

	dataDir = "datasets/";
    edge_test = dataDir+graph+ "_Edge.txt";  //edge query test file
    neighbour_test = dataDir+graph + "_Neighbor.txt"; //neighbour query test file
    cc_test = dataDir+graph + "_CC.txt";   //cc query test file
    adv_test = dataDir+graph + "_AddVertex.txt"; //add vertex test file
    ade_test = dataDir+graph + "_AddEdge.txt";  //add edge test file

    //Generating keys
    cout << "Generating Keyset.." << endl;
    key_iv = key_gen();
    cout << endl;

    //Encrypt Graph
    cout << "Running Encryption for " << graph << "..." << endl;
    encrypt_graph(graph, key_iv);
    cout << endl;

    //Edge Query Test
    cout << "Running Edge Query Test..." << endl;
    edge_query_test(graph,edge_test);
    cout << endl;

    //Neighbour Query Test
    cout << "Running Neighbour Query Test..." << endl;
    neighbour_query_test(graph,neighbour_test);
    cout << endl;

    //CC Query Test
    cout << "Running CC Query Test..." << endl;
    cc_query_test(graph,cc_test);
    cout << endl;

    //Add vertex Query Test
    cout << "Running Add vertex Query Test..." << endl;
    add_vertex_query_test(graph,adv_test);
    cout << endl;

    //Add edge Query Test
    cout << "Running Add Edge Query Test..." << endl;
    add_edge_query_test(graph,ade_test);
    cout << endl;

    return 0;
}

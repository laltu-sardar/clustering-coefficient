

# generate random integer values
from random import seed
from random import randint

# seed random number generator
seed(1)

#dataSets = {'gowalla', 'enron', 'cahepph', 'roadnet' }
#numOfTest= 1000
dataSets = {'sample' }
numOfTest= 10

for dataset in dataSets:
    srcFile = open("./../datasets/"+dataset+"_src.txt", "r")
    vertexLeft=[]
    vertexRight=[]
    for line in srcFile.readlines():
        nums = line.split(' ') #use ''\t' for true dataset
        vertexLeft.append(int (nums[0]))
        vertexRight.append(int (nums[1].replace('\n','')))
    maxElement= max([max(vertexLeft), max(vertexRight)])



    #1. CC Query data
    print "Generating CC query test Data\n"
    l  = len(vertexLeft)
    destFile = open("test_data/"+dataset+"_CC.txt", "w+")
    vertexSet=set([])
    while(1):
        vertexId = randint(0 , l-1)
        vertexSet.add(vertexLeft[vertexId])
        l2 = len (vertexSet)
        if l2 >= numOfTest:
            break
    for num in vertexSet:
        destFile.write(str(num)+"\n")
    destFile.close()

    print "Generating neighbor query test Data\n"
    #2. neighbor Query data
    l  = len(vertexLeft)
    destFile = open("test_data/"+dataset+"_Neighbor.txt", "w+")
    vertexSet=set([])
    while(1):
        vertexId = randint(0 , l-1)
        vertexSet.add(vertexLeft[vertexId])
        if len (vertexSet) >= numOfTest:
            break
    for num in vertexSet:
        destFile.write(str(num)+"\n")
    destFile.close()
    #3. Enc Query data-- _src File
    # Not needed

    #4. Edge Query Data
    print "Generating Edge query test Data\n"
    l  = len(vertexLeft)
    destFile = open("test_data/"+dataset+"_Edge.txt", "w+")
    ctr=0
    while(ctr<numOfTest):
        vert_l = randint(0 , maxElement)
        vert_r = randint(0 , maxElement)
        destFile.write(str(vert_l)+"\t"+str(vert_r)+"\n")
        ctr = ctr+1
    destFile.close()


    #5. AddVertex Query data
    print "Generating AddVertex query test Data\n"
    vertexSet=set([])
    while(1):
        vertexId = randint( maxElement+1, 5*maxElement)
        vertexSet.add(vertexId)
        if len (vertexSet)>=numOfTest:
            break
    destFile = open("test_data/"+dataset+"_AddVertex.txt", "w+")
    for num in vertexSet:
        destFile.write(str(num)+"\n")
    destFile.close()


    #6 AddEdge Query data
    print "Generating AddEdge query test Data\n"
    l  = len(vertexLeft)
    edgeSet=set([])
    leftSet = set([])
    rightSet = set([])
    for i in range(l):
        edge = (vertexLeft[i], vertexRight[i])
        edgeSet.add(edge)
        leftSet.add(vertexLeft[i])
        rightSet.add(vertexRight[i])

    testEdgeSet = set([])
    while(1):
        vert_l = randint( 0, maxElement)
        vert_r = randint( 0, maxElement)
        edge = (vert_l, vert_r)
        if edge not in edgeSet:
            if ((vert_l != vert_r) and (vert_l in leftSet) and (vert_r in rightSet)):
                testEdgeSet.add(edge)
        if len (testEdgeSet)>=numOfTest:
            break
    destFile = open("test_data/"+dataset+"_AddEdge.txt", "w+")
    for edge in testEdgeSet:
        destFile.write(str(edge[0])+"\t"+str(edge[1])+"\n")
    destFile.close()

    srcFile.close()
    print "test files are Generated Succesfully\n"
